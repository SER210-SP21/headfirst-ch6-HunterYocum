package edu.quinnipiac.secretmessage
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import edu.quinnipiac.secretmessage.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}